<h1 align="center"> PREMIUM SCRIPT
<h2 align="center">Network VPN</h2>

<h2 align="center">

![Hits](https://img.shields.io/badge/SSH-SlowDNS-8020f3?style=for-the-badge&logo=Cloudflare&logoColor=white&edge_flat=false)
![Hits](https://img.shields.io/badge/SSH-Websocket-8020f3?style=for-the-badge&logo=Cloudflare&logoColor=white&edge_flat=false)
![Hits](https://img.shields.io/badge/XRAY-Vmess-f34b20?style=for-the-badge&logo=Cloudflare&logoColor=white&edge_flat=false)
![Hits](https://img.shields.io/badge/XRAY-VLess-f34b20?style=for-the-badge&logo=Cloudflare&logoColor=white&edge_flat=false)
![Hits](https://img.shields.io/badge/XRAY-Trojan-f34b20?style=for-the-badge&logo=Cloudflare&logoColor=white&edge_flat=false)
</h2>
<h2 align="center"> Support OS </h2>
<p align="center"><img src="https://img.shields.io/static/v1?style=for-the-badge&logo=debian&label=Debian%209&message=Stretch&color=purple"> <img src="https://img.shields.io/static/v1?style=for-the-badge&logo=debian&label=Debian%2010&message=Buster&color=purple">  <img src="https://img.shields.io/static/v1?style=for-the-badge&logo=ubuntu&label=Ubuntu%2018&message=Lts&color=red"> <img src="https://img.shields.io/static/v1?style=for-the-badge&logo=ubuntu&label=Ubuntu%2020&message=Lts&color=red">
</p>
  
  ### TESTED ON OS 
- UBUNTU 18
- UBUNTU 20
### NOTES !!
- MINIMUM 1GB RAM
### FEATURES
- Add 1GB SwapRAM
- Dynamic Installation
- Tuning Profiles On The Server
- Add Fail2ban
- Add Panel Bot Tele ( coming soon )
- Add Bot Notif Riwayat Trx 
- Add Bot Auto Create Akun ssh or xray premium ( coming soon )
### BUY PREMIUM, CONTACT OWNER SCRIPT
### Whatshapp 
https://wa.me/+6282164649858/
### Telegram
https://t.me/RAIKAZUSTORE
### SETTING CLOUDFLARE
```
- SSL/TLS : FULL
- SSL/TLS Recommender : OFF
- GRPC : ON
- WEBSOCKET : ON
- Always Use HTTPS : OFF
- UNDER ATTACK MODE : OFF
```

<img src="https://img.shields.io/badge/UPDATE%20_&_%20UPGRADE DEBIAN 11,12-blue">
<pre><code>apt update -y && apt upgrade -y && apt dist-upgrade -y && reboot</code></pre>
<img src="https://img.shields.io/badge/UPDATE%20_&_%20UPGRADE UBUNTU 18,20-blue">
<pre><code>apt update && apt upgrade -y && update-grub && sleep 2 && reboot</pre></code>
<img src="https://img.shields.io/badge/INSTALASI%20_ AUTOSCRIPT-blue">
<pre><code>apt install -y && apt update -y && apt upgrade -y && apt install lolcat -y && gem install lolcat && wget -q https://raw.githubusercontent.com/RaikazuWebId/xvpn/main/main.sh && chmod +x main.sh && ./main.sh</pre></code>

### MENU, UPDATE, MANUAL
* main menu
```html
menu
```
* for menu updates 
```html
update
```
* For manual update
```html
wget -q https://raw.githubusercontent.com/RaikazuWebId/xvpn/main/files/update && chmod +x update && ./update
```
### SUPPORT 
<pre><code>>>> Service & Port
- Open SSH                : 443, 80, 22         
- DNS (SLOWDNS)           : 443, 80, 53          
- Dropbear                : 443, 109, 80        
- Dropbear Websocket      : 443, 109
- UDP Custom              : 1-65535          
- SSH Websocket SSL       : 443                  
- SSH Websocket           : 80                 
- OpenVPN SSL             : 443                   
- OpenVPN Websocket SSL   : 443                  
- OpenVPN TCP             : 443, 1194            
- OpenVPN UDP             : 2200              
- Nginx Webserver         : 443, 80, 81          
- Haproxy Loadbalancer    : 443, 80              
- DNS Server              : 443, 53               
- DNS Client              : 443, 88               
- XRAY DNS (SLOWDNS)      : 443, 80, 53        
- XRAY Vmess TLS          : 443                 
- XRAY Vmess gRPC         : 443                 
- XRAY Vmess None TLS     : 80                   
- XRAY Vless TLS          : 443                 
- XRAY Vless gRPC         : 443                  
- XRAY Vless None TLS     : 80                    
- Trojan gRPC             : 443                
- Trojan WS               : 443                  
- Shadowsocks WS          : 443                  
- Shadowsocks gRPC        : 443 </pre><code>
